package com.cogni.productcrudv2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductCrudV2Application {

	public static void main(String[] args) {
		SpringApplication.run(ProductCrudV2Application.class, args);
	}

}
